package de.suitepad.packagelist.receivers;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import de.suitepad.packagelist.MainActivity;

/**
 * Created by tarek on 4/6/17.
 */

public class PackageChangedBroadcastReceiver extends BroadcastReceiver
{
    @Override
    public void onReceive( Context context, Intent intent )
    {
        //triggered whenever any change happens to any package
        //should inform activity
        Uri data = intent.getData();
        String pkgName = data.toString().substring( data.getScheme().length() + 1 ); //remove 'package:'

        Intent mainActivity = new Intent( context, MainActivity.class );
        mainActivity.putExtra( MainActivity.EXTRA_PACKAGE_NAME, pkgName );
        if ( intent.getAction() == "android.intent.action.PACKAGE_ADDED" )
        {
            mainActivity.putExtra( MainActivity.EXTRA_PACKAGE_DETAILS, MainActivity.PACKAGE_INSTALL );
        }
        else if ( intent.getAction() == "android.intent.action.PACKAGE_REMOVED" )
        {
            mainActivity.putExtra( MainActivity.EXTRA_PACKAGE_DETAILS, MainActivity.PACKAGE_UNINSTALL );
        }
        else if ( intent.getAction() == "android.intent.action.PACKAGE_CHANGED" )
        {
            mainActivity.putExtra( MainActivity.EXTRA_PACKAGE_DETAILS, MainActivity.PACKAGE_CHANGED );
        }
        context.startActivity( mainActivity );
    }
}
